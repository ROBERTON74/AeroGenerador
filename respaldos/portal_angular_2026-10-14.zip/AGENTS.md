# AGENTS.md

## Contexto

Esta carpeta contiene la version Angular moderna del portal academico **AeroGenerador**. Es la version preferente para mostrar el proyecto con una estetica mas actual, tecnologica e industrial, manteniendo el contenido del portal original.

El portal original estatico sigue en:

```text
../portal_aerogenerador
```

La aplicacion principal del aerogenerador 3D sigue en:

```text
../../app_aerogenerador
```

## Identidad

- El nombre principal visible debe seguir siendo **AeroGenerador**.
- No sustituir el H1 por frases genericas.
- El enfoque visual puede ser empresarial, industrial y puntero, pero el proyecto sigue destinado a defensa academica para la Universidad Complutense de Madrid.
- El subtitulo actual es: `Portal academico interactivo de visualizacion tecnica eolica`.

## Objetivo visual

El portal debe verse como una plataforma de empresa privada puntera del sector energetico:

- Interfaz tipo producto industrial.
- Paneles oscuros y limpios.
- Sensacion de dashboard SCADA moderno.
- Capas de datos, modelo y visualizacion.
- Tarjetas de telemetria y estado operativo.
- Renders y videos Blender integrados como material de defensa tecnica.

No debe parecer una landing page generica ni una plantilla basica de Angular.

## Contenido que debe mantenerse

El contenido base viene del portal original y no debe eliminarse:

- Acceso a la aplicacion principal en `http://127.0.0.1:5177/`.
- Explicacion de ESIOS y API key.
- Datos: ESIOS 551, 31.679 MW, turbina tipo 5 MW, refresco cada 5 minutos.
- Videos Blender HD.
- Papers tecnicos: DEL, vida util/RUL, rainflow Cp Ct.
- Metodologia: web interactiva, Blender, alcance de datos.
- Entregables: web, Blender, videos y memoria/documentacion.

## Estructura relevante

```text
portal_aerogenerador_angular/
|-- angular.json
|-- package.json
|-- public/
|   `-- assets/
|       |-- media/
|       |-- papers/
|       `-- renders/
`-- src/
    |-- index.html
    |-- styles.css
    `-- app/
        |-- app.ts
        |-- app-new.html
        `-- app.css
```

## Comandos

Instalar dependencias si hace falta:

```bash
npm install
```

Arrancar en desarrollo:

```bash
npm.cmd start -- --host 0.0.0.0 --port 4200
```

Compilar para verificar:

```bash
npm.cmd run build
```

URL de desarrollo:

```text
http://localhost:4200/
```

## Notas de implementacion

- El componente principal esta en `src/app/app.ts`.
- La plantilla usada es `src/app/app-new.html`.
- Los estilos principales del portal estan en `src/app/app.css`.
- Los assets deben referenciarse desde `assets/...`, porque Angular sirve `public/` como raiz publica.
- Si se anaden nuevos videos o renders, copiarlos a `public/assets`.
- No mover ni borrar el portal HTML original sin una peticion explicita.

## Verificacion

Antes de entregar cambios en esta carpeta:

- Ejecutar `npm.cmd run build`.
- Comprobar que `http://localhost:4200/` carga.
- Revisar que el H1 siga diciendo **AeroGenerador**.
- Confirmar que los enlaces a videos, papers y aplicacion principal siguen funcionando.

## Estado aprobado el 14 de octubre de 2026

Consultar `AVANCES_2026-10-14.md` antes de continuar. El usuario pidió guardar el progreso y conservar específicamente el bloque animado de simulación (laboratorio) que mostró en una captura. Los cambios globales de interactividad del portal se deshicieron; no recuperarlos sin una nueva petición. El laboratorio con sus controles y tarjetas sí debe conservarse.
